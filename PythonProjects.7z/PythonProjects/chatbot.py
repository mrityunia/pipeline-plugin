# from flask import Flask
# from chatterbot import ChatBot
# from chatterbot.trainers import ListTrainer
# from chatterbot.trainers import ChatterBotCorpusTrainer
# import os
#
# # Create a new chat bot named Charlie
# chatbot = ChatBot('Cbot')
#
# trainer = ListTrainer(chatbot)
#
#
# #trainer = ChatterBotCorpusTrainer(chatbot)
#
# for files in os.listdir('C:/Users/VinayBhai\Desktop\Python\chatterbot-corpus-master\chatterbot-corpus-master\chatterbot_corpus\data\english/'):
#     data = open('C:/Users/VinayBhai\Desktop\Python\chatterbot-corpus-master\chatterbot-corpus-master\chatterbot_corpus\data\english/'+files, 'r').readlines()
#     trainer.train(data)
#
#
# trainer.train('chatterbot.corpus.english')
#
# # Now we can export the data to a file
# trainer.export_for_training('./my_export.json')
#
#
# while True:
#     request = input('You : ')
#     response = chatbot.get_response(request)
#     print('Myra : ', response)
