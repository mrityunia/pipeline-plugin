from flask import Flask,render_template,request
from flask import Flask
from chatterbot import ChatBot
from chatterbot.trainers import ListTrainer
from chatterbot.trainers import ChatterBotCorpusTrainer
import os

chatbot = ChatBot('Cbot')

trainer = ListTrainer(chatbot)


#trainer = ChatterBotCorpusTrainer(chatbot)

for files in os.listdir('C:/Users/VinayBhai\Desktop\Python\chatterbot-corpus-master\chatterbot-corpus-master\chatterbot_corpus\data\english/'):
    data = open('C:/Users/VinayBhai\Desktop\Python\chatterbot-corpus-master\chatterbot-corpus-master\chatterbot_corpus\data\english/'+files, 'r').readlines()
    trainer.train(data)


app = Flask(__name__)
@app.route('/')
def index():
    return render_template('index.html')
@app.route('/process', methods = ['POST'])
def process():
    user_input = request.form['user_input']
    bot_response = chatbot.get_response(user_input)
    bot_response = str(bot_response)
    print("Myra : "+bot_response)
    return render_template('index.html', user_input=user_input, bot_response=bot_response)


if __name__ == '__main__':
    app.run(debug=True, port=5002)
